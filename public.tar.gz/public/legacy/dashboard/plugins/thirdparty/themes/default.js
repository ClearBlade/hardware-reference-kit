Speedometer.themes['default'] = {
  dial       : 'Gray',
  rim        : 'SlateGray',
  rimArc     : 'Gainsboro',
  thresh     : 'LawnGreen',
  center     : 'Black',
  nose       : 'SlateGray',
  hand       : 'Black',
  handShine  : 'SlateGray',
  handShineTo: 'Black',
  ticks      : 'Black',
  marks      : 'Black',
  strings    : 'Black',
  digits     : 'Black',
  font       : 'Sans-Serif'
};
